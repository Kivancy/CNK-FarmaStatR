# FSR-TN-PBE-01 · Yeniden üretim paketi

CNK-FarmaStatR · 16.10.2026 · Teknik not v0.8 ile birlikte.
Araştırma ve eğitim amaçlıdır; GxP ortamında valide edilmiş sistem değildir.

Bu paket, metodolojik kontrol raporu 02'nin (16.10.2026) M-12 maddesinde istenen bağımsız yeniden üretim içindir. Bütün dosyalar proje deposundaki dosyaların kopyasıdır; SHA-256 değerleri `SHA256SUMS.txt` içindedir.

## Raporun (a)–(g) listesiyle eşleşme

| Rapor maddesi | Paketteki karşılığı |
|---|---|
| (a) Simülasyon manifesti | `simulasyon/FSR-TN-PBE-01/asama2_senaryolar.csv` (725 senaryo; `asama2_liste.R` üretir). Doğrulaması: `asama2_dogrula.R` → `asama2_dogrulama.csv` (24 kontrol). Aşama 1'in listesi `asama1.R` içindedir (360 senaryo). |
| (b) Veri üretimi betiği | R paketi `CNKfarmastatr_1.0.0.9000.tar.gz`: `R/invitro_fast.R` (`invitro_gen`, `invitro_components`, `invitro_drift`) ve `R/invitro_grid.R` 0.2.0 (`invitro_scenario`). |
| (c) Yavaş referans PBE ile hızlı PBE karşılaştırması | Paket testleri TC-F1, TC-F2 (`pbe_fast` = `calc_pbe`, göreli fark ≤ 1e-12) ve TC-F9 (uçtan uca akış: veri üretimi → `calc_pbe` kararı; m = 1, 2, 3 ve q > 0). `calc_pbe` validasyonlu çekirdektir (`R/pbe_core.R`, SHA-256 `inst/validasyon/CEKIRDEK_SHA256.txt`). |
| (d) FDA örnek verisi ve beklenen kararlar | `ornek_psg020929()` (paket; PSG 020929 Ek, simüle örnek) ve `inst/validasyon/pbe/` test verileri (P1–P6) ile 213 + 25 kontrol. |
| (e) EMA (a)/(b)/(c) sınır testleri | TC-F3 (elle hesap), TC-F4 (sayısal REML ile; iç çözüm ve sınır durumları), TC-F8 (sınır payı ve eşleşik MCSE). SAS bağımsız kontrolü: `belgeler/teknik_notlar/FSR-TN-PBE-01_ek/sas/`. |
| (f) CSV çıktıları | `asama1_sonuc.csv`, `asama2_sonuc.csv`, ek tekrarlar (`asama1_ektekrar.csv`, `asama2_ektekrar.csv`), tablolar (`asama1_tablo113.csv`), bağımsız tekrar (`bagimsiz_tekrar.csv`), koşu kayıtları (`*_kayit.csv`). |
| (g) sessionInfo ve hash değerleri | `sessionInfo.txt`, `SHA256SUMS.txt`, paket test sonucu `test_sonuclari.csv` (25 test bloğu, 722 beklenti, başarısız 0, atlanan 0). |

## Yeniden üretim adımları

1. R ≥ 4.1 ve `testthat` kurulu olsun. UTF-8 yerel ayarı gerekir (devralınan test betikleri Türkçe karakter içerir; Linux'ta örn. `LANG=C.UTF-8`).
2. Paketi kurun: `R CMD INSTALL CNKfarmastatr_1.0.0.9000.tar.gz`
3. Testler: paket kaynağını açıp `NOT_CRAN=true Rscript -e 'testthat::test_local("CNKfarmastatr")'` (beklenen: başarısız 0, atlanan 0).
4. Betikleri paket kökünde (bu klasörde) çalıştırın; her biri girdisini `simulasyon/FSR-TN-PBE-01/` altından okur:
   - `Rscript simulasyon/FSR-TN-PBE-01/asama1.R` → `asama1_sonuc.csv` (yaklaşık 3 dk)
   - `Rscript simulasyon/FSR-TN-PBE-01/asama2_liste.R` → `asama2_senaryolar.csv`
   - `Rscript simulasyon/FSR-TN-PBE-01/asama2_dogrula.R` → `asama2_dogrulama.csv`
   - `Rscript simulasyon/FSR-TN-PBE-01/asama2.R` → `asama2_sonuc.csv` (yaklaşık 10 dk)
   - `Rscript simulasyon/FSR-TN-PBE-01/asama1_ektekrar.R`, `asama1_tablo113.R`, `bagimsiz_tekrar.R`
5. Aynı R sürümü ve RNG türüyle (Mersenne-Twister / Inversion; seed'ler betiklerde ve kayıt dosyalarında) sonuçlar birebir aynı çıkmalıdır. Farklı R sürümünde kayan nokta farkları 1e-12 düzeyindedir.

## Bağımsız seed ile yeniden üretim (M-12)

`bagimsiz_tekrar.R`: Tablo 11.1–11.2'nin 48 yöntem hücresi (3 × 10; p_B 0 / 0,10 / 0,30; dört δ) yeni seed (20261019) ve 40.000 tekrarla yeniden koşuldu. En büyük |z| = 2,65; |z| > 3 olan hücre yok. Not: Aşama 1'de bütün senaryolar aynı seed'le koştuğu için (ortak rastgele sayılar) bu 48 karşılaştırma bağımsız değildir; aynı akıştan gelen sapmalar birlikte görünür. En büyük farklı hücre (EMA (a), p_B 0,30, δ₀) iki ek seed'le daha koşuldu: %17,5 ve %17,7 (Aşama 1: %17,1; MCSE 0,4).

## Kapsam dışı

- Teknik not ve kaynak kılavuzlar: telifli kılavuz ve makaleler pakette yoktur.
- `chow1452.csv`, Chow ve Liu (2008) Tablo 14.5.2–14.5.3'ten aktarılmıştır (KK-33).
